package com.bytedance.practice5;

public class Constants {
    public static final String BASE_URL = "https://api-android-camp.bytedance.com/zju/invoke/";
    public static final String token = "WkpVLWJ5dGVkYW5jZS1hbmRyb2lk";
    //TODO 1这里写上自己的学号和名字
    public static final String STUDENT_ID = "4fce0ce8e655283dd3f9e460c8a5490e";
//    public static final String STUDENT_ID = "4fce";
    public static final String USER_NAME = "QAQza";

}
