package recycler;

import java.util.ArrayList;
import java.util.List;

public class DataSet {
    public static List<Data> getData() {
        List<Data> res = new ArrayList();
        res.add(new Data("刘大"));
        res.add(new Data("吴二"));
        res.add(new Data("张三"));
        res.add(new Data("李四"));
        res.add(new Data("王五"));
        res.add(new Data("赵六"));
        res.add(new Data("钱七"));
        res.add(new Data("陈八"));
        res.add(new Data("孙九"));
        res.add(new Data("周十"));
        return res;
    }
}
