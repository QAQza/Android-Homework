package recycler;

public class Data {
    String value;
    public Data(String _value) {
        value = _value;
    }
}
