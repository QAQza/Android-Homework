package recycler;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.chapter3.homework.R;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.MyViewHolder> {

    private List<Data> myDataset = new ArrayList<>();

    public RecyclerViewAdapter(List<Data> data) {
        myDataset.addAll(data);
    }

    @Override
    public @NotNull MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(parent.getContext())
                .inflate(R.layout.recycler_item, parent, false));
    }

    @Override
    public int getItemCount() {return myDataset.size();}

    @Override
    public void onBindViewHolder(MyViewHolder holder, final int pos) {
        holder.onBind(pos, myDataset.get(pos));
    }


    public static class MyViewHolder extends RecyclerView.ViewHolder {
        private final TextView txtIndex;
        private final TextView txtContent;

        public MyViewHolder(View v) {
            super(v);
            txtIndex = v.findViewById(R.id.txt_index);
            txtContent = v.findViewById(R.id.txt_content);
        }

        @SuppressLint("SetTextI18n")
        public void onBind(int position, Data data) {
            txtIndex.setText(position + ".  "); // 用 pos 做编号。
            txtContent.setText(data.value);
        }
    }
}
