package com.byted.camp.todolist.db;

import android.provider.BaseColumns;
import android.provider.SearchRecentSuggestions;

public final class TodoContract {

    // TODO 1. 定义创建数据库以及升级的操作
    public static final String SQL_CREATE_TABLE =
            "create table " + TodoNote.TABLE_NAME + "(" +
                    TodoNote._ID + " integer primary key autoincrement," +
                    TodoNote.TITLE + " text," +
                    TodoNote.DATETIME + " datetime not null," +
                    TodoNote.ISFINISHED + " integer default 0," +
                    TodoNote.PRIORITY + " integer default 0" +
                    ");";
    public static final String SQL_DROP_TABLE =
            "drop table if exist " + TodoNote.TABLE_NAME;
    public static final String SQL_ADD_ATTRIBUTE =
            "alter table " + TodoNote.TABLE_NAME + " add " + TodoNote.PRIORITY + " int"; // but why...?


    private TodoContract() {
    }

    public static class TodoNote implements BaseColumns {
        // TODO 2.此处定义表名以及列名
        public static final String TABLE_NAME = "todolist";
        public static final String TITLE = "_title";
        public static final String DATETIME = "addtime";
        public static final String ISFINISHED = "isfinished";
        public static final String PRIORITY = "priority";
    }

}
