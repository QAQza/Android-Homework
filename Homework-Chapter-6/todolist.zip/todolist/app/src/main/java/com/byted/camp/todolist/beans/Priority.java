package com.byted.camp.todolist.beans;

public enum Priority {
    High(2, 0x7FFF3300),
    Medium(1, 0x7FFFCC00),
    Low(0, 0x7FFFFF66);

    public final int intValue;
    public final int color;

    Priority(int intValue, int color) {
        this.intValue = intValue;
        this.color = color;
    }

    public static Priority from(int intValue) {
        for (Priority priority : Priority.values()) {
            if (priority.intValue == intValue) {
                return priority;
            }
        }
        return Priority.Low; // default
    }
}
