package com.example.hw2;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.i("MainActivity", "onResume");
        InitView();
    }

    private void InitView() {
        findViewById(R.id.btn_1).setOnClickListener(this::OnClick);
        findViewById(R.id.btn_2).setOnClickListener(this::OnClick);
        findViewById(R.id.btn_3).setOnClickListener(this::OnClick);
        findViewById(R.id.btn_4).setOnClickListener(this::OnClick);
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.i("MainActivity", "onStart");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.i("MainActivity", "onResume");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.i("MainActivity", "onRestart");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.i("MainActivity", "onPause");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.i("MainActivity", "onStop");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i("MainActivity", "onDestroy");
    }

    @SuppressLint("NonConstantResourceId")
    public void OnClick(View v) {
        switch (v.getId()) {
            case R.id.btn_1:
                Log.i("MainAct_OnClick","press btn_1");
                startActivity(new Intent().setClass(MainActivity.this, MainActivity2.class));
                break;
            case R.id.btn_2:
                Log.i("MainAct_OnClick","press btn_2");
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.baidu.com"))); // 注意要加 https://才行。
                break;
            case R.id.btn_3:
                Log.i("MainAct_OnClick","press btn_3");
                startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:"+"12345678901"))); // 写了 tel: 就能传递电话号码。
                break;
            case R.id.btn_4:
                Log.i("MainAct_OnClick","press btn_4");
                startActivity(new Intent(MainActivity.this,MainActivity3.class));
                break;
            default:
                throw new IllegalStateException("Unexpected value: " + v.getId());
        }
    }

}