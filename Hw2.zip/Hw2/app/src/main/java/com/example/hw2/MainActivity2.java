package com.example.hw2;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {

    private int nz_count;
    TextView txt4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        nz_count = 0;
        txt4 = findViewById(R.id.txt_4);
        InitView();
/*
        Button btn1 = findViewById(R.id.btn_1);
        Button btn2 = findViewById(R.id.btn_2);
*/

    }
    private void InitView() {
        findViewById(R.id.btn_1).setOnClickListener(this::onClick);
        findViewById(R.id.btn_2).setOnClickListener(this::onClick);
        findViewById(R.id.btn_3).setOnClickListener(this::onClick);
    }

    @SuppressLint({"NonConstantResourceId", "SetTextI18n"})
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_1:
                Intent intent = new Intent(MainActivity2.this, MainActivity.class);
                startActivity(intent);
                break;
            case R.id.btn_2:
                Toast.makeText(MainActivity2.this,"This is a toast.",Toast.LENGTH_SHORT).show();
                break;
            case R.id.btn_3:
                ++ nz_count;
                txt4.setText("您的女装次数"+":"+nz_count);
                break;
            default:
                throw new IllegalStateException("Unexpected value: " + v.getId());
        }
    }

}