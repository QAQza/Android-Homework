package recycler;

import java.util.ArrayList;
import java.util.List;

public class TestDataSet {
    public static List<TestData> getData() {
        List<TestData> result = new ArrayList();
        result.add(new TestData("QAQ", "530w"));
        result.add(new TestData("QBQ", "529w"));
        result.add(new TestData("QCQ", "528w"));
        result.add(new TestData("QDQ", "527w"));
        result.add(new TestData("QEQ", "526w"));
        result.add(new TestData("QFQ", "525w"));
        result.add(new TestData("QGQ", "524w"));
        result.add(new TestData("QHQ", "523w"));
        result.add(new TestData("QIQ", "522w"));
        result.add(new TestData("QJQ", "521w"));
        result.add(new TestData("QKQ", "520w"));
        return result;
    }
}
