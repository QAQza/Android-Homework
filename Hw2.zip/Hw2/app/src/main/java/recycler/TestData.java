package recycler;

public class TestData {
    String title;
    String hot;
    public TestData(String _title,String _hot) {
        title = _title;
        hot = _hot;
    }
}
