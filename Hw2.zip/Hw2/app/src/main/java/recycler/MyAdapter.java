package recycler;

import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.hw2.R;

import java.util.ArrayList;
import java.util.List;
//import com.example.hw2.R;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {

    private List<TestData> mDataset = new ArrayList<>();
    private IOnItemClickListener mItemClickListener;

    @Override
    public void onBindViewHolder(MyViewHolder holder, final int pos) {
        holder.onBind(pos, mDataset.get(pos));
        holder.setOnClickListener(v -> {
            if (mItemClickListener != null) {
                mItemClickListener.onItemCLick(pos, mDataset.get(pos));
            }
        });
        holder.setOnLongClickListener(v -> {
            if (mItemClickListener != null) {
                mItemClickListener.onItemLongCLick(pos, mDataset.get(pos));
            }
            return false;
        });
    }

    // Return the size of your dataset (invoked by the layout manager)
    @Override
    public int getItemCount() {return mDataset.size();}

    public interface IOnItemClickListener {

        void onItemCLick(int position, TestData data);

        void onItemLongCLick(int position, TestData data);
    }

    public MyAdapter(List<TestData> tmpDataset) {
        mDataset.addAll(tmpDataset);
    }

    public void setOnItemClickListener(IOnItemClickListener listener) {
        mItemClickListener = listener;
    }

    public void addData(int position, TestData data) {
        mDataset.add(position, data);
        notifyItemInserted(position);
        if (position != mDataset.size()) {
            //刷新改变位置item下方的所有Item的位置,避免索引错乱
            notifyItemRangeChanged(position, mDataset.size() - position);
        }
    }

    public void removeData(int position) {
        if (null != mDataset && mDataset.size() > position) {
            mDataset.remove(position);
            notifyItemRemoved(position);
            if (position != mDataset.size()) {
                //刷新改变位置item下方的所有Item的位置,避免索引错乱
                notifyItemRangeChanged(position, mDataset.size() - position);
            }
        }
    }

    @Override
    public MyAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(parent.getContext())
                .inflate(R.layout.recycler_item, parent, false));
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder { // 神奇的泛型，居然能定义在这里。。。

        private TextView txtIdx;
        private TextView txtTit;
        private TextView txtHot;
        private View contentView;

        public MyViewHolder(View v) {
            super(v);
            contentView = v;
            txtIdx = v.findViewById(R.id.txt_index);
            txtTit = v.findViewById(R.id.txt_title);
            txtHot = v.findViewById(R.id.txt_hot);
        }

        public void onBind(int position, TestData data) {
            txtIdx.setText(new StringBuilder().append(position).append(".  ").toString()); // 用 pos 做编号。
            txtTit.setText(data.title);
            txtHot.setText(data.hot);
            if(position < 5) txtIdx.setTextColor(Color.parseColor("#ffd700")); // 黄色。
            else txtIdx.setTextColor(Color.parseColor("#ffffff")); // 白色。
        }

        public void setOnClickListener(View.OnClickListener listener) {
            if(listener != null) contentView.setOnClickListener(listener);
            else Log.d("MyViewHolder","listener = NULL");
        }

        public void setOnLongClickListener(View.OnLongClickListener listener) {
            if (listener != null) contentView.setOnLongClickListener(listener);
            else Log.d("MyViewHolder","long listener = NULL");
        }
    }
}

