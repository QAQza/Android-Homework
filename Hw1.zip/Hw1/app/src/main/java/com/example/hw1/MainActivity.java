package com.example.hw1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btn1 = findViewById(R.id.btn_1);
        Button btn2 = findViewById(R.id.btn_2);
        final TextView txt1 = findViewById(R.id.txt_1);
        final ImageView img1 = findViewById(R.id.img_1);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("btn press", "btn1 is pressed");
                txt1.setText("you have just pressed the first button");
                img1.setImageDrawable(getResources().getDrawable(R.drawable.qaq));
            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("btn press", "btn2 is pressed");
                txt1.setText("you have just pressed the second button");
                img1.setImageDrawable(getResources().getDrawable(R.drawable.qbq));
            }
        });
    }
}